# Arian Plank Dock Theme
My Favorite Plank Theme which I think it's very cool, Isn't i?! :)

# Installation:
```
cd arian-plank-theme/
sh install.sh 
```

Enjoy it!

Don't forget to rate and share your comments!

Github: https://github.com/aryanhosseini
